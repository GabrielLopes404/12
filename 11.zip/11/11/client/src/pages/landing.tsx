import { useState, useEffect } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowRight, 
  CheckCircle2, 
  TrendingUp, 
  DollarSign, 
  Shield, 
  Zap,
  Users,
  BarChart3,
  Star,
  Sparkles,
  Target,
  Clock,
  LineChart,
  PieChart,
  Wallet,
  CreditCard,
  FileText,
  Calculator,
  TrendingDown,
  Building2,
  Phone,
  Mail,
  MapPin,
  ChevronDown,
  Heart,
  Briefcase,
  Home,
  Smartphone,
  Receipt,
  Globe,
  Lock,
  Headphones,
  Award
} from "lucide-react";
import { Link } from "wouter";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import logoUrl from "@assets/generated_images/Lucrei_financial_software_logo_280b14ff.png";

const fadeInUp = {
  initial: { opacity: 0, y: 60 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 }
};

const stagger = {
  animate: {
    transition: {
      staggerChildren: 0.1
    }
  }
};

const features = [
  {
    icon: Zap,
    title: "Baixo custo",
    description: "Preço super justo que cabe no seu bolso",
    gradient: "from-violet-500 to-purple-500"
  },
  {
    icon: Heart,
    title: "Fácil de usar",
    description: "Super intuitivo! Descomplicado e do nosso jeito",
    gradient: "from-pink-500 to-rose-500"
  },
  {
    icon: Sparkles,
    title: "Simples e completo",
    description: "Tudo o que você precisa para uma boa gestão financeira",
    gradient: "from-blue-500 to-cyan-500"
  },
  {
    icon: TrendingUp,
    title: "Evolua a cada dia",
    description: "Equipe dedicada no desenvolvimento de melhorias",
    gradient: "from-indigo-500 to-purple-500"
  },
];

const mainFeatures = [
  {
    icon: Receipt,
    title: "Contas a Pagar e Receber",
    description: "Com o recurso de 'Lançamentos Recorrentes' você lança uma única vez todas as suas despesas e recebimentos. Mais praticidade no seu dia a dia!",
    color: "text-blue-600"
  },
  {
    icon: LineChart,
    title: "Fluxo de Caixa",
    description: "O Fluxo de Caixa é a espinha dorsal de qualquer negócio bem-sucedido. Com o nosso sistema, você terá uma visão clara de como o dinheiro está fluindo na sua empresa.",
    color: "text-violet-600"
  },
  {
    icon: CreditCard,
    title: "Pagamentos pendentes",
    description: "Todas as contas pendentes em um único lugar. Controle total sobre o que precisa ser pago e recebido.",
    color: "text-purple-600"
  },
  {
    icon: Lock,
    title: "Gestão e Permissões de Acessos",
    description: "Tenha controle total sobre as informações financeiras dentro da sua empresa. Os administradores podem definir as ações que os demais usuários podem realizar no sistema.",
    color: "text-indigo-600"
  },
  {
    icon: Building2,
    title: "Gestão de Contas Bancárias",
    description: "Monitore seus saldos bancários atuais dos registros das transações financeiras e conciliação bancária. Gerencie suas contas de investimentos, cartões pré-pago e a caixa.",
    color: "text-blue-600"
  },
  {
    icon: FileText,
    title: "Gestão de Faturas",
    description: "Crie e envie faturas profissionais para seus clientes. Acompanhe pagamentos e mantenha seu fluxo de caixa organizado.",
    color: "text-purple-600"
  }
];

const stats = [
  { value: "+3.610", label: "Empresas cadastradas", icon: Building2 },
  { value: "+3.610", label: "Usuários cadastrados", icon: Users },
  { value: "+3.610", label: "Contas criadas", icon: Wallet },
  { value: "+36.100", label: "Transações realizadas", icon: TrendingUp },
];

const testimonials = [
  {
    name: "Eduardo Henrique",
    role: "CEO da TechFlow",
    company: "Empresa de tecnologia e desenvolvimento",
    content: "O Lucrei me proporcionou liberdade para o grau de meus negócios sem minhas empresas. Com ele, eu li fazemos cada uma rotina, consigo visualizar as despesas e o consequente passo uma total transparência.",
    avatar: "EH",
    rating: 5
  },
  {
    name: "Denys Lucio",
    role: "MEI Autônomo",
    content: "Desde que comecei a usar a plataforma, minha vida financeira virou um caos significativo e simples e organizado. É tão claro! Cada despesa está documentada em detalhes claramente.",
    avatar: "DL",
    rating: 5
  },
  {
    name: "Bruna Soledo Alves da Costa",
    role: "Gestão Consultora e Arquiteta",
    content: "Uso Lucrei há 28 meses agora! Bem organizado, rápida e agrupada plataforma além do sistema financeiro com muito prazer a meu trabalho. Até hoje não vi algo semelhante nos demais sistemas.",
    avatar: "BS",
    rating: 5
  }
];

const plans = [
  {
    name: "Empresarial Mensal",
    price: "39",
    period: "/mês",
    description: "Cobrança realizada mensalmente apenas quando quiser",
    discount: "Economize 12%",
    features: [
      "Controle financeiro para empresas",
      "Gestão de contratos",
      "Até 3 usuários",
      "Acesso a API de integração",
      "Até 1 Usuário",
      "50 GB de Disco"
    ],
    color: "from-emerald-500 to-green-600",
    popular: false
  },
  {
    name: "Empresarial Semestral",
    price: "209",
    period: "/semestre",
    description: "Cobrança única realizada semestralmente",
    discount: "Economize 12%",
    features: [
      "Controle financeiro para empresas",
      "Gestão de contratos",
      "Até 3 usuários",
      "Acesso a API de integração",
      "Até 1 Usuário",
      "50 GB de Disco"
    ],
    color: "from-blue-500 to-indigo-600",
    popular: true
  },
  {
    name: "Empresarial Anual",
    price: "399",
    period: "/ano",
    description: "Cobrança única realizada anualmente",
    discount: "Economize 15%",
    features: [
      "Controle financeiro para empresas",
      "Gestão de contratos",
      "Até 3 usuários",
      "Acesso a API de integração",
      "Até 5 Usuários",
      "50 GB de Disco"
    ],
    color: "from-pink-500 to-purple-600",
    popular: false
  }
];

const faqs = [
  {
    question: "O que é o Lucrei?",
    answer: "Lucrei é um sistema completo de gestão financeira voltado para MEI, micro e pequenas empresas. Com ele você gerencia suas receitas, despesas, fluxo de caixa e muito mais de forma simples e intuitiva."
  },
  {
    question: "É possível fazer informações de outros sistemas para o Lucrei?",
    answer: "Sim! Oferecemos integração via API e também importação de arquivos OFX para facilitar a migração dos seus dados."
  },
  {
    question: "Preciso criar uma conta para poder usar o Lucrei?",
    answer: "Sim, é necessário criar uma conta para utilizar todas as funcionalidades do sistema. Você pode começar com 7 dias grátis sem necessidade de cartão de crédito."
  },
  {
    question: "É necessário contratar uma assinatura para usar ou 7 dias gratuitos?",
    answer: "Você pode usar gratuitamente por 7 dias. Após esse período, será necessário escolher um dos nossos planos para continuar utilizando o sistema."
  },
  {
    question: "Durante o período de teste, posso pedir ajuda em caso de dúvidas?",
    answer: "Sim! Nossa equipe de suporte está disponível 24/7 para ajudar você em qualquer dúvida, mesmo durante o período de teste gratuito."
  }
];

export default function LandingNew() {
  const [scrollY, setScrollY] = useState(0);
  const { scrollYProgress } = useScroll();
  const heroY = useTransform(scrollYProgress, [0, 1], [0, 500]);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-background overflow-hidden">
      {/* Navigation */}
      <motion.nav 
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className="fixed top-0 left-0 right-0 z-50 border-b backdrop-blur-xl bg-background/80 supports-[backdrop-filter]:bg-background/60"
      >
        <div className="container mx-auto px-6">
          <div className="flex h-20 items-center justify-between">
            <motion.div 
              className="flex items-center gap-3 group cursor-pointer"
              whileHover={{ scale: 1.05 }}
            >
              <div className="relative">
                <motion.div 
                  className="absolute inset-0 bg-gradient-to-r from-primary to-chart-2 rounded-full blur-md opacity-50"
                  animate={{ opacity: [0.5, 0.8, 0.5] }}
                  transition={{ duration: 2, repeat: Infinity }}
                />
                <img src={logoUrl} alt="Lucrei" className="relative h-12 w-12" />
              </div>
              <span className="text-3xl font-bold bg-gradient-to-r from-primary via-chart-2 to-chart-4 bg-clip-text text-transparent">
                Lucrei
              </span>
            </motion.div>
            <div className="hidden md:flex items-center gap-6">
              <a href="#features" className="text-sm font-medium hover:text-primary transition-colors">
                Recursos
              </a>
              <a href="#for-who" className="text-sm font-medium hover:text-primary transition-colors">
                Para quem
              </a>
              <a href="#testimonials" className="text-sm font-medium hover:text-primary transition-colors">
                Depoimentos
              </a>
              <a href="#pricing" className="text-sm font-medium hover:text-primary transition-colors">
                Preços
              </a>
              <Link href="/admin/dashboard">
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button variant="outline" className="border-2 border-purple-500/50 hover:border-purple-500 hover:bg-purple-500/10 text-purple-600 dark:text-purple-400 font-semibold">
                    <Briefcase className="mr-2 h-4 w-4" />
                    Trabalhe Aqui?
                  </Button>
                </motion.div>
              </Link>
              <Link href="/dashboard">
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button className="bg-gradient-to-r from-emerald-500 via-green-500 to-teal-500 hover:shadow-lg hover:shadow-emerald-500/50 font-semibold">
                    <Zap className="mr-2 h-4 w-4" />
                    Entrar Agora
                  </Button>
                </motion.div>
              </Link>
            </div>
          </div>
        </div>
      </motion.nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 md:pt-40 md:pb-32 overflow-hidden">
        {/* Animated Background Gradients */}
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-chart-2/5 to-background" />
        <div className="absolute inset-0 bg-grid-white/[0.02] bg-[size:50px_50px]" />
        
        <motion.div 
          className="absolute top-0 right-0 w-[800px] h-[800px] bg-gradient-to-br from-primary/30 to-chart-2/30 rounded-full blur-3xl"
          animate={{ 
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.5, 0.3]
          }}
          transition={{ duration: 8, repeat: Infinity }}
        />
        <motion.div 
          className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-gradient-to-tr from-chart-4/30 to-purple-500/30 rounded-full blur-3xl"
          animate={{ 
            scale: [1.2, 1, 1.2],
            opacity: [0.2, 0.4, 0.2]
          }}
          transition={{ duration: 10, repeat: Infinity }}
        />

        <div className="container mx-auto px-6 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div 
              className="space-y-8"
              initial={{ opacity: 0, x: -100 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.2 }}
              >
                <Badge className="bg-gradient-to-r from-primary to-chart-2 text-white border-0 hover:shadow-lg hover:shadow-primary/50 mb-6">
                  <Sparkles className="mr-1 h-3 w-3" />
                  7 Dias Grátis - Sem Cartão de Crédito
                </Badge>
              </motion.div>
              
              <motion.h1 
                className="text-5xl md:text-7xl font-bold leading-tight"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
              >
                Você no comando das
                <motion.span 
                  className="block mt-2 bg-gradient-to-r from-primary via-chart-2 to-chart-4 bg-clip-text text-transparent"
                  animate={{ 
                    backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"]
                  }}
                  transition={{ duration: 5, repeat: Infinity }}
                  style={{ backgroundSize: "200% 200%" }}
                >
                  finanças.
                </motion.span>
              </motion.h1>
              
              <motion.p 
                className="text-xl text-muted-foreground leading-relaxed"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
              >
                Tudo o que você precisa para gerenciar suas finanças sem pagar mais por isso.
                <span className="block mt-2 text-primary font-semibold">Comece nossos planos →</span>
              </motion.p>
              
              <motion.div 
                className="flex flex-col sm:flex-row gap-4"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.7 }}
              >
                <Link href="/dashboard">
                  <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    <Button 
                      size="lg" 
                      className="text-lg px-8 bg-gradient-to-r from-emerald-500 via-green-500 to-teal-500 hover:shadow-2xl hover:shadow-emerald-500/50 group font-bold"
                    >
                      <Zap className="mr-2 h-5 w-5" />
                      Entrar Agora
                      <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </motion.div>
                </Link>
                <Link href="/admin/dashboard">
                  <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    <Button 
                      size="lg" 
                      variant="outline"
                      className="text-lg px-8 border-2 border-purple-500/50 hover:border-purple-500 hover:bg-purple-500/10 text-purple-600 dark:text-purple-400 font-bold group"
                    >
                      <Briefcase className="mr-2 h-5 w-5" />
                      Trabalhe Aqui?
                      <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </motion.div>
                </Link>
              </motion.div>
              
              <motion.div
                className="flex items-center gap-4"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.9 }}
              >
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <div className="h-1 w-1 rounded-full bg-muted-foreground" />
                  <span>Teste gratuitamente por 7 dias</span>
                </div>
                <div className="h-4 w-px bg-border" />
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <div className="h-1 w-1 rounded-full bg-muted-foreground" />
                  <span>Sem cartão de crédito</span>
                </div>
              </motion.div>
            </motion.div>

            <motion.div 
              className="relative"
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
            >
              {/* Dashboard Preview Card */}
              <motion.div 
                className="relative"
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 4, repeat: Infinity }}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-primary to-chart-2 rounded-3xl blur-3xl opacity-30" />
                <Card className="relative border-2 shadow-2xl overflow-hidden backdrop-blur-xl bg-background/80">
                  <CardContent className="p-8 space-y-6">
                    {/* Phone Mockup - Ultra Premium */}
                    <motion.div 
                      className="relative bg-gradient-to-br from-gray-900 via-slate-800 to-gray-900 rounded-[2.5rem] p-3 shadow-2xl max-w-[300px] mx-auto border-4 border-gray-700"
                      whileHover={{ scale: 1.02 }}
                    >
                      {/* Notch */}
                      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-gray-900 rounded-b-2xl z-10" />
                      
                      <div className="relative bg-gradient-to-br from-white via-gray-50 to-white rounded-[2rem] p-5 space-y-4 overflow-hidden">
                        {/* Background decoration */}
                        <div className="absolute top-0 right-0 w-40 h-40 bg-gradient-to-br from-primary/10 to-chart-2/10 rounded-full blur-3xl" />
                        
                        <div className="relative">
                          <div className="flex items-center justify-between pb-3 border-b-2 border-gradient-to-r from-primary/20 to-chart-2/20">
                            <div className="flex items-center gap-2">
                              <div className="h-2 w-2 rounded-full bg-gradient-to-r from-primary to-chart-2" />
                              <span className="text-xs font-semibold text-gray-600">Meu Extrato</span>
                            </div>
                            <span className="text-xs font-bold bg-gradient-to-r from-primary to-chart-2 bg-clip-text text-transparent">Novembro</span>
                          </div>
                          
                          <div className="space-y-3 mt-3">
                            <div className="bg-gradient-to-r from-primary/10 via-chart-2/10 to-chart-4/10 rounded-xl p-3 border border-primary/20">
                              <div className="flex items-center justify-between text-xs">
                                <span className="text-gray-500 font-medium">Saldo 2024 ↓</span>
                                <span className="font-mono font-bold text-lg bg-gradient-to-r from-primary to-chart-2 bg-clip-text text-transparent">R$ 35.689,42</span>
                              </div>
                            </div>
                            
                            {/* Calendar Mini - Premium */}
                            <div className="bg-white rounded-xl p-3 shadow-sm border border-gray-100">
                              <div className="grid grid-cols-7 gap-1.5 text-[10px] text-center">
                                {['D', 'S', 'T', 'Q', 'Q', 'S', 'S'].map((d, i) => (
                                  <div key={i} className="text-gray-400 font-bold">{d}</div>
                                ))}
                                {Array.from({ length: 30 }, (_, i) => (
                                  <motion.div 
                                    key={i} 
                                    className={`p-1.5 rounded-lg font-medium transition-all ${
                                      i === 14 
                                        ? 'bg-gradient-to-br from-primary to-chart-2 text-white font-bold shadow-lg shadow-primary/30' 
                                        : 'text-gray-600 hover:bg-gray-100'
                                    }`}
                                    whileHover={{ scale: 1.1 }}
                                  >
                                    {i + 1}
                                  </motion.div>
                                ))}
                              </div>
                            </div>
                          </div>
                          
                          <div className="pt-3 border-t-2 border-gradient-to-r from-primary/20 to-chart-2/20 space-y-2 mt-3">
                            <div className="text-[10px] text-gray-500 font-semibold uppercase tracking-wide">Transações recentes</div>
                            {[
                              { name: "Folha Pessoal", value: "-R$ 3.840,00", positive: false, icon: "💼" },
                              { name: "Vendas Online", value: "+R$ 12.450,00", positive: true, icon: "🛒" }
                            ].map((t, i) => (
                              <motion.div 
                                key={i} 
                                className={`flex justify-between items-center text-xs rounded-lg p-2 ${
                                  t.positive ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'
                                }`}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: 1 + i * 0.2 }}
                                whileHover={{ scale: 1.02 }}
                              >
                                <div className="flex items-center gap-2">
                                  <span>{t.icon}</span>
                                  <span className="text-gray-700 font-medium">{t.name}</span>
                                </div>
                                <span className={`font-mono font-bold ${t.positive ? 'text-green-600' : 'text-red-600'}`}>
                                  {t.value}
                                </span>
                              </motion.div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </motion.div>

                    {/* Desktop Dashboard Preview - Ultra Premium */}
                    <motion.div 
                      className="relative bg-gradient-to-br from-white via-gray-50 to-white rounded-2xl shadow-2xl p-5 space-y-4 border-2 border-gray-100 overflow-hidden"
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.5 }}
                    >
                      {/* Background decoration */}
                      <div className="absolute -top-20 -right-20 w-60 h-60 bg-gradient-to-br from-chart-2/10 to-chart-4/10 rounded-full blur-3xl" />
                      
                      <div className="relative">
                        <div className="flex items-center gap-3 text-xs mb-4">
                          <div className="flex gap-1.5">
                            <div className="w-3 h-3 rounded-full bg-gradient-to-br from-red-400 to-red-500 shadow-sm" />
                            <div className="w-3 h-3 rounded-full bg-gradient-to-br from-yellow-400 to-yellow-500 shadow-sm" />
                            <div className="w-3 h-3 rounded-full bg-gradient-to-br from-green-400 to-green-500 shadow-sm" />
                          </div>
                          <div className="flex-1 bg-gradient-to-r from-gray-100 to-gray-50 rounded-lg px-3 py-1.5 border border-gray-200">
                            <span className="font-mono text-gray-600 font-medium">lucrei.app/dashboard</span>
                          </div>
                        </div>
                        
                        <div className="space-y-3">
                          <div className="grid grid-cols-3 gap-3">
                            {[
                              { label: "Receitas", value: "R$ 98.450", color: "from-emerald-500 via-green-500 to-teal-500", icon: "📈" },
                              { label: "Despesas", value: "R$ 43.210", color: "from-rose-500 via-red-500 to-pink-500", icon: "📉" },
                              { label: "Lucro", value: "R$ 55.240", color: "from-blue-500 via-indigo-500 to-purple-500", icon: "💰" }
                            ].map((item, i) => (
                              <motion.div 
                                key={i}
                                className={`relative bg-gradient-to-br ${item.color} rounded-xl p-3 text-white shadow-lg overflow-hidden`}
                                whileHover={{ scale: 1.05, y: -2 }}
                                initial={{ opacity: 0, scale: 0.8 }}
                                animate={{ opacity: 1, scale: 1 }}
                                transition={{ delay: 0.7 + i * 0.1 }}
                              >
                                <div className="absolute top-0 right-0 text-3xl opacity-20">{item.icon}</div>
                                <div className="relative space-y-1">
                                  <div className="text-[10px] font-semibold opacity-90 uppercase tracking-wide">{item.label}</div>
                                  <div className="text-base font-bold font-mono">{item.value}</div>
                                </div>
                              </motion.div>
                            ))}
                          </div>

                          {/* Chart Preview - Premium */}
                          <div className="bg-gradient-to-br from-gray-50 via-white to-gray-50 rounded-xl p-4 border-2 border-gray-100 shadow-inner">
                            <div className="flex items-end justify-around h-24 gap-2">
                              {[60, 80, 55, 90, 70, 95, 75].map((height, i) => (
                                <motion.div 
                                  key={i}
                                  className="flex-1 relative group"
                                  initial={{ height: 0 }}
                                  animate={{ height: `${height}%` }}
                                  transition={{ delay: 1 + i * 0.1, duration: 0.5 }}
                                >
                                  <div className="absolute inset-0 bg-gradient-to-t from-primary via-chart-2 to-chart-4 rounded-t-lg shadow-lg group-hover:shadow-xl transition-shadow" />
                                  <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-white rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity" />
                                </motion.div>
                              ))}
                            </div>
                            <div className="flex justify-between mt-3 text-[9px] text-gray-400 font-medium">
                              <span>Jan</span>
                              <span>Fev</span>
                              <span>Mar</span>
                              <span>Abr</span>
                              <span>Mai</span>
                              <span>Jun</span>
                              <span>Jul</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  </CardContent>
                </Card>
              </motion.div>

              {/* Floating Badge - Ultra Premium */}
              <motion.div 
                className="absolute -top-8 -right-8 bg-gradient-to-br from-white via-green-50 to-emerald-50 border-2 border-green-200 rounded-3xl shadow-2xl p-5 hidden lg:block backdrop-blur-sm overflow-hidden"
                animate={{ 
                  y: [0, -15, 0],
                  rotate: [0, 3, 0]
                }}
                transition={{ duration: 4, repeat: Infinity }}
              >
                {/* Background glow */}
                <div className="absolute inset-0 bg-gradient-to-br from-green-400/20 to-emerald-500/20 rounded-3xl blur-xl" />
                
                <div className="relative flex items-center gap-4">
                  <div className="p-4 bg-gradient-to-br from-emerald-500 via-green-500 to-teal-500 rounded-2xl shadow-lg">
                    <TrendingUp className="h-7 w-7 text-white" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-600 font-semibold uppercase tracking-wide">Lucro Este Mês</p>
                    <p className="text-2xl font-bold font-mono bg-gradient-to-r from-emerald-600 to-green-600 bg-clip-text text-transparent">+R$ 55.240</p>
                    <div className="flex items-center gap-1 mt-1">
                      <div className="h-1 w-1 rounded-full bg-green-500 animate-pulse" />
                      <span className="text-[10px] text-green-600 font-medium">+23% vs mês anterior</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Why Section */}
      <section className="py-20 bg-gradient-to-b from-background to-muted/30">
        <div className="container mx-auto px-6">
          <motion.div 
            className="text-center mb-16 space-y-4"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold">
              Em poucas palavras. Por que o{" "}
              <span className="bg-gradient-to-r from-primary to-chart-4 bg-clip-text text-transparent">
                Lucrei é o melhor
              </span>{" "}
              sistema de gestão financeira?
            </h2>
          </motion.div>

          <motion.div 
            className="grid md:grid-cols-2 lg:grid-cols-4 gap-6"
            variants={stagger}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
          >
            {features.map((feature, i) => (
              <motion.div key={i} variants={fadeInUp}>
                <Card className="group relative overflow-hidden hover-elevate transition-all duration-500 border-2 hover:border-primary/50 cursor-pointer h-full">
                  <div className={`absolute inset-0 bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-500`} />
                  <CardContent className="p-6 space-y-4 relative">
                    <motion.div 
                      className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${feature.gradient} p-0.5`}
                      whileHover={{ scale: 1.1, rotate: 5 }}
                    >
                      <div className="w-full h-full rounded-2xl bg-background flex items-center justify-center">
                        <feature.icon className="h-8 w-8 text-primary" />
                      </div>
                    </motion.div>
                    <h3 className="text-xl font-bold group-hover:text-primary transition-colors">
                      {feature.title}
                    </h3>
                    <p className="text-muted-foreground leading-relaxed">
                      {feature.description}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* For Entrepreneurs Section */}
      <section id="for-who" className="py-24 overflow-hidden">
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="relative">
                <motion.div 
                  className="absolute inset-0 bg-gradient-to-r from-primary/20 to-chart-2/20 rounded-3xl blur-3xl"
                  animate={{ scale: [1, 1.1, 1] }}
                  transition={{ duration: 3, repeat: Infinity }}
                />
                <img 
                  src="https://images.unsplash.com/photo-1560250097-0b93528c311a?w=600&h=400&fit=crop" 
                  alt="Empreendedor" 
                  className="relative rounded-3xl shadow-2xl w-full object-cover h-[400px]"
                />
              </div>
            </motion.div>

            <motion.div
              className="space-y-6"
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <Badge className="bg-gradient-to-r from-emerald-500 to-green-600 text-white border-0">
                <Briefcase className="mr-1 h-3 w-3" />
                Para Empreendedores
              </Badge>
              <h2 className="text-4xl font-bold">
                O{" "}
                <span className="bg-gradient-to-r from-emerald-500 to-green-600 bg-clip-text text-transparent">
                  Lucrei é para você
                </span>
                {" "}empreendedor.
              </h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Você empresário e empresária que possui uma{" "}
                <span className="font-semibold text-foreground">MEI, Micro ou Pequena Empresa de Prestação de Serviços</span>,
                está a um passo de melhorar a sua gestão financeira. Experimente o Lucrei!
              </p>
              <Link href="/login">
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button size="lg" className="bg-gradient-to-r from-emerald-500 to-green-600 text-white hover:shadow-xl">
                    Quero Testar
                  </Button>
                </motion.div>
              </Link>
              <p className="text-sm text-muted-foreground">
                Teste gratuitamente por 7 dias
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* For Family Section */}
      <section className="py-24 bg-muted/30 overflow-hidden">
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              className="space-y-6 order-2 lg:order-1"
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <Badge className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white border-0">
                <Home className="mr-1 h-3 w-3" />
                Para Você e Sua Família
              </Badge>
              <h2 className="text-4xl font-bold">
                O{" "}
                <span className="bg-gradient-to-r from-blue-500 to-indigo-600 bg-clip-text text-transparent">
                  Lucrei é para você e sua família.
                </span>
              </h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Para você que quer ter o controle dos gastos "na ponta do lápis" e deseja{" "}
                <span className="font-semibold text-foreground">gerenciar as finanças pessoais</span>{" "}
                da melhor maneira possível, o Lucrei é a plataforma ideal. Teste e comprove!
              </p>
              <Link href="/login">
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button size="lg" className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white hover:shadow-xl">
                    Quero Testar
                  </Button>
                </motion.div>
              </Link>
              <p className="text-sm text-muted-foreground">
                Teste gratuitamente por 7 dias
              </p>
            </motion.div>

            <motion.div
              className="order-1 lg:order-2"
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="relative">
                <motion.div 
                  className="absolute inset-0 bg-gradient-to-l from-blue-500/20 to-indigo-600/20 rounded-3xl blur-3xl"
                  animate={{ scale: [1, 1.1, 1] }}
                  transition={{ duration: 3, repeat: Infinity }}
                />
                <img 
                  src="https://images.unsplash.com/photo-1511895426328-dc8714191300?w=600&h=400&fit=crop" 
                  alt="Família" 
                  className="relative rounded-3xl shadow-2xl w-full object-cover h-[400px]"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Dashboard Preview Section */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-purple-500/5 to-background" />
        
        <div className="container mx-auto px-6 relative z-10">
          <motion.div 
            className="text-center mb-16 space-y-4"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold">
              Não deixe a gestão das suas finanças de lado.
              <span className="block mt-2 bg-gradient-to-r from-primary to-chart-4 bg-clip-text text-transparent">
                Evolua com o Lucrei.
              </span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Obtenha um panorama geral com o nosso dashboard
            </p>
          </motion.div>

          <motion.div
            className="relative max-w-5xl mx-auto"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <motion.div 
              className="absolute inset-0 bg-gradient-to-r from-primary/30 to-purple-500/30 rounded-3xl blur-3xl"
              animate={{ opacity: [0.3, 0.6, 0.3] }}
              transition={{ duration: 3, repeat: Infinity }}
            />
            <Card className="relative border-2 shadow-2xl overflow-hidden">
              <CardContent className="p-0">
                <img 
                  src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=1200&h=600&fit=crop" 
                  alt="Dashboard Preview" 
                  className="w-full h-auto"
                />
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </section>

      {/* Main Features Section */}
      <section id="features" className="py-24 bg-gradient-to-b from-background via-muted/20 to-background">
        <div className="container mx-auto px-6">
          <motion.div 
            className="text-center mb-16 space-y-4"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <Badge className="bg-primary/10 text-primary border-primary/20">
              Tudo que você precisa
            </Badge>
            <h2 className="text-4xl md:text-5xl font-bold">
              Funcionalidades essenciais que facilitam a{" "}
              <span className="bg-gradient-to-r from-primary to-chart-4 bg-clip-text text-transparent">
                gestão financeira
              </span>{" "}
              da sua empresa.
            </h2>
          </motion.div>

          <motion.div 
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
            variants={stagger}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
          >
            {mainFeatures.map((feature, i) => (
              <motion.div key={i} variants={fadeInUp}>
                <Card className="group h-full hover-elevate transition-all duration-500 hover:shadow-xl border-2 hover:border-primary/30">
                  <CardContent className="p-6 space-y-4">
                    <motion.div 
                      className={`w-12 h-12 rounded-xl bg-gradient-to-br from-primary/20 to-purple-500/20 flex items-center justify-center`}
                      whileHover={{ scale: 1.1, rotate: 10 }}
                    >
                      <feature.icon className={`h-6 w-6 ${feature.color}`} />
                    </motion.div>
                    <h3 className="text-xl font-bold group-hover:text-primary transition-colors">
                      {feature.title}
                    </h3>
                    <p className="text-muted-foreground leading-relaxed">
                      {feature.description}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary via-chart-2 to-chart-4" />
        <div className="absolute inset-0 bg-grid-white/[0.05] bg-[size:20px_20px]" />
        
        <div className="container mx-auto px-6 relative z-10">
          <motion.div 
            className="text-center mb-12 space-y-4"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white">
              O Sistema de gestão financeira que é o queridinho do Brasil
            </h2>
            <p className="text-xl text-white/90">
              Estamos em todos os estados brasileiros.
            </p>
          </motion.div>

          <motion.div 
            className="grid grid-cols-2 md:grid-cols-4 gap-8"
            variants={stagger}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
          >
            {stats.map((stat, i) => (
              <motion.div 
                key={i} 
                className="text-center space-y-3"
                variants={fadeInUp}
              >
                <motion.div 
                  className="mx-auto w-16 h-16 rounded-2xl bg-white/10 backdrop-blur-sm flex items-center justify-center mb-4"
                  whileHover={{ scale: 1.1, rotate: 5 }}
                >
                  <stat.icon className="h-8 w-8 text-white" />
                </motion.div>
                <motion.div 
                  className="text-5xl font-bold text-white"
                  initial={{ scale: 0 }}
                  whileInView={{ scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.2 + i * 0.1, type: "spring" }}
                >
                  {stat.value}
                </motion.div>
                <div className="text-lg text-white/90">{stat.label}</div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-24 bg-muted/30">
        <div className="container mx-auto px-6">
          <motion.div 
            className="text-center mb-16 space-y-4"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold">
              Depoimento de clientes
            </h2>
            <p className="text-xl text-muted-foreground">
              Saber que nossos clientes estão satisfeitos significa muito para nós.
            </p>
          </motion.div>

          <motion.div 
            className="grid md:grid-cols-3 gap-8"
            variants={stagger}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
          >
            {testimonials.map((testimonial, i) => (
              <motion.div key={i} variants={fadeInUp}>
                <Card className="h-full hover-elevate transition-all duration-500 hover:shadow-xl">
                  <CardContent className="p-6 space-y-4">
                    <div className="flex gap-1">
                      {Array.from({ length: testimonial.rating }).map((_, i) => (
                        <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                    <p className="text-muted-foreground leading-relaxed">
                      "{testimonial.content}"
                    </p>
                    <div className="flex items-center gap-3 pt-4 border-t">
                      <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-chart-2 flex items-center justify-center text-white font-bold">
                        {testimonial.avatar}
                      </div>
                      <div>
                        <p className="font-semibold">{testimonial.name}</p>
                        <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-24">
        <div className="container mx-auto px-6">
          <motion.div 
            className="text-center mb-16 space-y-4"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold">
              Por apenas{" "}
              <span className="bg-gradient-to-r from-primary to-chart-4 bg-clip-text text-transparent">
                R$ 39,90/mês
              </span>, você terá o que precisa para gerenciar suas finanças!
            </h2>
          </motion.div>

          <motion.div 
            className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto"
            variants={stagger}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
          >
            {plans.map((plan, i) => (
              <motion.div key={i} variants={fadeInUp}>
                <Card className={`relative h-full hover-elevate transition-all duration-500 ${plan.popular ? 'border-2 border-primary shadow-2xl scale-105' : ''}`}>
                  {plan.popular && (
                    <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                      <Badge className="bg-gradient-to-r from-primary to-chart-2 text-white border-0 px-4 py-1">
                        Mais Popular
                      </Badge>
                    </div>
                  )}
                  <CardContent className="p-8 space-y-6">
                    <div className="space-y-2">
                      <Badge className={`bg-gradient-to-r ${plan.color} text-white border-0`}>
                        {plan.discount}
                      </Badge>
                      <h3 className="text-2xl font-bold">{plan.name}</h3>
                      <p className="text-sm text-muted-foreground">{plan.description}</p>
                    </div>
                    
                    <div className="flex items-baseline gap-2">
                      <span className="text-5xl font-bold font-mono bg-gradient-to-r from-primary to-chart-4 bg-clip-text text-transparent">
                        R${plan.price}
                      </span>
                      <span className="text-muted-foreground">{plan.period}</span>
                    </div>

                    <ul className="space-y-3">
                      {plan.features.map((feature, j) => (
                        <li key={j} className="flex items-start gap-2">
                          <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                          <span className="text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>

                    <Link href="/login">
                      <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                        <Button 
                          className={`w-full ${plan.popular ? `bg-gradient-to-r ${plan.color} text-white` : ''}`}
                          variant={plan.popular ? 'default' : 'outline'}
                        >
                          Começar Agora
                        </Button>
                      </motion.div>
                    </Link>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>

          <motion.div 
            className="mt-12 text-center"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
          >
            <p className="text-sm text-muted-foreground mb-4">
              Crie sua conta gratuita e depois de 7 dias você escolhe o plano ideal!
            </p>
            <Link href="/login">
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button size="lg" className="bg-gradient-to-r from-primary to-chart-2 text-white">
                  Criar Conta Empresarial Grátis - 7 Dias
                </Button>
              </motion.div>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-24 bg-muted/30">
        <div className="container mx-auto px-6">
          <motion.div 
            className="text-center mb-16 space-y-4"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold">
              <span className="bg-gradient-to-r from-primary to-chart-4 bg-clip-text text-transparent">
                Dúvidas
              </span>{" "}
              sobre o Lucrei
            </h2>
          </motion.div>

          <motion.div 
            className="max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <Accordion type="single" collapsible className="space-y-4">
              {faqs.map((faq, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                >
                  <AccordionItem value={`item-${i}`} className="border rounded-lg px-6 bg-background">
                    <AccordionTrigger className="hover:text-primary">
                      {faq.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                </motion.div>
              ))}
            </Accordion>
          </motion.div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary via-chart-2 to-chart-4" />
        <div className="absolute inset-0 bg-grid-white/[0.05] bg-[size:20px_20px]" />
        
        <div className="container mx-auto px-6 relative z-10 text-center">
          <motion.div 
            className="max-w-3xl mx-auto space-y-8"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <motion.div
              animate={{ scale: [1, 1.05, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <Sparkles className="h-16 w-16 text-white mx-auto mb-6" />
            </motion.div>
            <h2 className="text-4xl md:text-5xl font-bold text-white">
              Comece a transformar suas finanças hoje
            </h2>
            <p className="text-xl text-white/90">
              Junte-se a milhares de empresas que já revolucionaram sua gestão financeira
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/login">
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button 
                    size="lg" 
                    className="text-lg px-8 bg-white text-primary hover:bg-white/90 hover:shadow-2xl group"
                  >
                    <Sparkles className="mr-2 h-5 w-5" />
                    Iniciar Teste Gratuito
                    <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </motion.div>
              </Link>
            </div>
            <p className="text-sm text-white/70">
              7 dias grátis • Sem cartão de crédito • Cancele quando quiser
            </p>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-12 bg-background">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <img src={logoUrl} alt="Lucrei" className="h-10 w-10" />
                <span className="text-2xl font-bold bg-gradient-to-r from-primary to-chart-2 bg-clip-text text-transparent">
                  Lucrei
                </span>
              </div>
              <p className="text-sm text-muted-foreground">
                ©2025 Lucrei Tecnologia Ltda.
              </p>
              <p className="text-xs text-muted-foreground">
                CNPJ: 38.209.485/0001-03
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Aproveite o Lucrei</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#features" className="hover:text-primary">Quem Somos</a></li>
                <li><a href="#pricing" className="hover:text-primary">Planos</a></li>
                <li><a href="#features" className="hover:text-primary">Fale Conosco</a></li>
                <li><a href="#features" className="hover:text-primary">Comunidade Lucrei</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Sobre o Lucrei</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#features" className="hover:text-primary">Quem Somos</a></li>
                <li><a href="#pricing" className="hover:text-primary">Funcionalidades</a></li>
                <li><a href="#features" className="hover:text-primary">Dashboard Interativo</a></li>
                <li><a href="#features" className="hover:text-primary">Contas a Pagar e Receber</a></li>
                <li><a href="#features" className="hover:text-primary">Fluxo de Caixa</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Suporte</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-center gap-2">
                  <Headphones className="h-4 w-4" />
                  Suporte 24/7
                </li>
                <li className="flex items-center gap-2">
                  <Award className="h-4 w-4" />
                  Central de Ajuda
                </li>
                <li className="flex items-center gap-2">
                  <Globe className="h-4 w-4" />
                  Blog
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-muted-foreground">
            <p>Política de Cookies | Termos de uso | Privacidade</p>
            <p>Transformando gestão financeira desde 2024</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
