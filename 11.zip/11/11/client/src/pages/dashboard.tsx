import { motion } from "framer-motion";
import { MetricCard } from "@/components/metric-card";
import { ProgressRing } from "@/components/progress-ring";
import { CalendarWidget } from "@/components/calendar-widget";
import { EmptyState } from "@/components/empty-state";
import { 
  DollarSign, 
  TrendingUp, 
  TrendingDown, 
  Clock,
  Plus,
  Upload,
  FileText,
  Info,
  Wallet,
  ArrowRight,
  Zap
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

const cashFlowData = [
  { month: "Jan", receitas: 45000, despesas: 32000 },
  { month: "Fev", receitas: 52000, despesas: 38000 },
  { month: "Mar", receitas: 48000, despesas: 35000 },
  { month: "Abr", receitas: 61000, despesas: 42000 },
  { month: "Mai", receitas: 55000, despesas: 39000 },
  { month: "Jun", receitas: 67000, despesas: 45000 },
];

const recentTransactions = [
  { id: 1, description: "Pagamento Cliente ABC", value: 5200, type: "receita", date: "2024-11-01" },
  { id: 2, description: "Fornecedor XYZ Ltda", value: -2800, type: "despesa", date: "2024-11-01" },
  { id: 3, description: "Serviço Consultoria", value: 3500, type: "receita", date: "2024-10-31" },
  { id: 4, description: "Aluguel Escritório", value: -4200, type: "despesa", date: "2024-10-30" },
  { id: 5, description: "Venda Produto Premium", value: 8900, type: "receita", date: "2024-10-30" },
];

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.4 }
};

const stagger = {
  animate: {
    transition: {
      staggerChildren: 0.1
    }
  }
};

export default function Dashboard() {
  return (
    <div className="flex-1 space-y-6 p-6">
      {/* Header */}
      <motion.div 
        className="flex items-center justify-between"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="space-y-1">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary via-chart-2 to-chart-4 bg-clip-text text-transparent animate-gradient">
            Bom dia, Gabriel.
          </h1>
          <p className="text-muted-foreground text-lg">Visão geral das suas finanças em tempo real</p>
        </div>
        <div className="flex gap-3">
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button variant="outline" data-testid="button-import-ofx" className="border-2 hover:border-primary/50 hover:bg-primary/5">
              <Upload className="h-4 w-4 mr-2" />
              Importar OFX
            </Button>
          </motion.div>
          <motion.div whileHover={{ scale: 1.05, y: -2 }} whileTap={{ scale: 0.95 }}>
            <Button data-testid="button-new-transaction" className="bg-gradient-to-r from-primary via-chart-2 to-chart-4 animate-gradient shadow-lg hover:shadow-xl hover:shadow-primary/50">
              <Plus className="h-4 w-4 mr-2" />
              Nova Transação
            </Button>
          </motion.div>
        </div>
      </motion.div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          {/* Previsto/Realizado no Mês */}
          <motion.div {...fadeInUp}>
            <Card className="border-2 border-primary/20 hover:border-primary/40 transition-all shadow-lg hover:shadow-xl hover:shadow-primary/10 backdrop-blur-sm bg-card/95">
              <CardHeader className="bg-gradient-to-r from-primary/5 via-chart-2/5 to-transparent">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2 text-xl">
                    <div className="p-2 bg-gradient-to-br from-primary to-chart-2 rounded-lg">
                      <Zap className="h-5 w-5 text-white" />
                    </div>
                    Previsto / realizado no mês
                  </CardTitle>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Badge variant="outline" className="font-mono bg-primary/10 border-primary/30">NOV/2025</Badge>
                    <span className="font-medium">Conta Principal</span>
                    <Info className="h-4 w-4 cursor-help hover:text-primary transition-colors" />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-8">
                  <motion.div 
                    className="space-y-4"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.2 }}
                  >
                    <div className="flex justify-center">
                      <ProgressRing
                        progress={100}
                        color="hsl(var(--chart-2))"
                        label="Recebido"
                      />
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between p-2 rounded-lg hover:bg-success/5 transition-colors">
                        <span className="text-sm font-medium text-muted-foreground">Recebido</span>
                        <span className="font-bold font-mono text-lg text-success">R$ 80,00</span>
                      </div>
                      <div className="flex items-center justify-between p-2 rounded-lg hover:bg-muted/50 transition-colors">
                        <span className="text-sm font-medium text-muted-foreground">Falta</span>
                        <span className="font-bold font-mono text-lg">R$ 0,00</span>
                      </div>
                      <div className="flex items-center justify-between p-2 rounded-lg hover:bg-muted/50 transition-colors">
                        <span className="text-sm font-medium text-muted-foreground">Previsto</span>
                        <span className="font-bold font-mono text-lg">R$ 80,00</span>
                      </div>
                    </div>
                  </motion.div>

                  <motion.div 
                    className="space-y-4"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.3 }}
                  >
                    <div className="flex justify-center">
                      <ProgressRing
                        progress={100}
                        color="hsl(var(--destructive))"
                        label="Pago"
                      />
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between p-2 rounded-lg hover:bg-destructive/5 transition-colors">
                        <span className="text-sm font-medium text-muted-foreground">Pago</span>
                        <span className="font-bold font-mono text-lg text-destructive">R$ 80,00</span>
                      </div>
                      <div className="flex items-center justify-between p-2 rounded-lg hover:bg-muted/50 transition-colors">
                        <span className="text-sm font-medium text-muted-foreground">Falta</span>
                        <span className="font-bold font-mono text-lg">R$ 0,00</span>
                      </div>
                      <div className="flex items-center justify-between p-2 rounded-lg hover:bg-muted/50 transition-colors">
                        <span className="text-sm font-medium text-muted-foreground">Previsto</span>
                        <span className="font-bold font-mono text-lg">R$ 80,00</span>
                      </div>
                    </div>
                  </motion.div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Fluxo de Caixa */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Card className="border-2 hover:border-primary/30 transition-colors">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-primary" />
                    Fluxo de caixa
                  </CardTitle>
                  <div className="text-sm text-muted-foreground flex items-center gap-2">
                    <Badge variant="outline" className="font-mono">NOV/2025</Badge>
                    <span>Conta Principal</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="mb-4">
                  <span className="text-2xl font-bold font-mono bg-gradient-to-r from-success to-emerald-600 bg-clip-text text-transparent">
                    R$ 1,00
                  </span>
                </div>
                <ResponsiveContainer width="100%" height={200}>
                  <LineChart data={cashFlowData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="month" className="text-xs" />
                    <YAxis className="text-xs" hide />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px'
                      }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="receitas" 
                      stroke="hsl(var(--primary))" 
                      strokeWidth={3}
                      dot={{ r: 4, fill: "hsl(var(--primary))" }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </motion.div>

          {/* Comparativo */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <Card className="border-2 hover:border-primary/30 transition-colors">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <BarChart className="h-5 w-5 text-primary" />
                    Comparativo
                  </CardTitle>
                  <div className="text-sm text-muted-foreground flex items-center gap-2">
                    <Badge variant="outline" className="font-mono">NOV/2025</Badge>
                    <span>Conta Principal</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    transition={{ duration: 0.2 }}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-success" />
                        <span className="text-sm font-medium">Recebimentos</span>
                      </div>
                      <span className="text-sm font-mono text-muted-foreground">-- % (R$ 0,00) ←</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-3 overflow-hidden">
                      <motion.div 
                        className="bg-gradient-to-r from-success to-emerald-500 h-3 rounded-full"
                        initial={{ width: 0 }}
                        animate={{ width: '75%' }}
                        transition={{ duration: 1, delay: 0.6 }}
                      />
                    </div>
                  </motion.div>
                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    transition={{ duration: 0.2 }}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-destructive" />
                        <span className="text-sm font-medium">Despesas</span>
                      </div>
                      <span className="text-sm font-mono text-muted-foreground">-- % (R$ 0,00) ←</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-3 overflow-hidden">
                      <motion.div 
                        className="bg-gradient-to-r from-destructive to-red-500 h-3 rounded-full"
                        initial={{ width: 0 }}
                        animate={{ width: '75%' }}
                        transition={{ duration: 1, delay: 0.7 }}
                      />
                    </div>
                  </motion.div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Últimas Atualizações */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
          >
            <Card className="border-2 hover:border-primary/30 transition-colors">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5 text-primary" />
                    Últimas atualizações em transações
                  </CardTitle>
                  <Info className="h-4 w-4 text-muted-foreground" />
                </div>
              </CardHeader>
              <CardContent>
                <EmptyState
                  icon={FileText}
                  title="Nenhum histórico encontrado"
                  description="Suas transações recentes aparecerão aqui quando você começar a usá-las"
                  gradient="from-primary to-chart-2"
                />
              </CardContent>
            </Card>
          </motion.div>
        </div>

        <div className="space-y-6">
          {/* Conta Principal */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="relative overflow-hidden group hover:shadow-xl transition-all duration-300 border-2 hover:border-primary/30">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-chart-2/5 opacity-0 group-hover:opacity-100 transition-opacity" />
              <CardHeader className="pb-3 relative z-10">
                <CardTitle className="text-base flex items-center gap-2">
                  <Wallet className="h-5 w-5 text-primary" />
                  Conta Principal
                </CardTitle>
              </CardHeader>
              <CardContent className="relative z-10">
                <div className="space-y-4">
                  <div className="p-4 rounded-xl bg-gradient-to-br from-success/10 to-emerald-500/10 border border-success/20">
                    <p className="text-sm font-medium text-muted-foreground mb-2">Saldo atual:</p>
                    <p className="text-3xl font-bold font-mono text-success" data-testid="balance-current">
                      R$ 0,00
                    </p>
                  </div>
                  <div className="p-4 rounded-xl bg-gradient-to-br from-primary/10 to-chart-2/10 border border-primary/20">
                    <p className="text-sm font-medium text-muted-foreground mb-2">Previsão do mês:</p>
                    <p className="text-2xl font-bold font-mono bg-gradient-to-r from-primary to-chart-2 bg-clip-text text-transparent">
                      R$ 80,00
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Calendário */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
          >
            <CalendarWidget />
          </motion.div>

          {/* Quick Stats */}
          <motion.div 
            className="grid grid-cols-2 gap-4"
            variants={stagger}
            initial="initial"
            animate="animate"
          >
            <motion.div variants={fadeInUp} whileHover={{ y: -4, scale: 1.02 }}>
              <Card className="relative overflow-hidden group hover:shadow-lg transition-all border-2 hover:border-success/30">
                <div className="absolute inset-0 bg-gradient-to-br from-success/5 to-emerald-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                <CardContent className="p-4 relative z-10">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="p-2 rounded-lg bg-gradient-to-br from-success to-emerald-500">
                      <TrendingUp className="h-4 w-4 text-white" />
                    </div>
                    <span className="text-xs font-medium text-muted-foreground">Receitas</span>
                  </div>
                  <p className="text-xl font-bold font-mono text-success">R$ 67.000</p>
                </CardContent>
              </Card>
            </motion.div>
            <motion.div variants={fadeInUp} whileHover={{ y: -4, scale: 1.02 }}>
              <Card className="relative overflow-hidden group hover:shadow-lg transition-all border-2 hover:border-destructive/30">
                <div className="absolute inset-0 bg-gradient-to-br from-destructive/5 to-red-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                <CardContent className="p-4 relative z-10">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="p-2 rounded-lg bg-gradient-to-br from-destructive to-red-500">
                      <TrendingDown className="h-4 w-4 text-white" />
                    </div>
                    <span className="text-xs font-medium text-muted-foreground">Despesas</span>
                  </div>
                  <p className="text-xl font-bold font-mono text-destructive">R$ 45.000</p>
                </CardContent>
              </Card>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
